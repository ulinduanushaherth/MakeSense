# ot_context/temporal/slicer.py

from typing import List


def temporal_slice(
    candidates: List[dict],
    mode: str = "retrieval_depth",
    T: int = 3,
):
    """
    Partition candidates into ordered temporal slices.

    Args:
        candidates: List of candidate dicts (must already be ordered).
        mode: Slicing strategy.
              - "retrieval_depth" (default): split by rank order
        T: Number of temporal slices.

    Returns:
        List[List[dict]]: ordered slices C¹, C², ..., Cᵀ
    """

    if T <= 1:
        return [candidates]

    if mode != "retrieval_depth":
        raise ValueError(f"Unsupported temporal slicing mode: {mode}")

    n = len(candidates)
    if n == 0:
        return []

    # Compute slice boundaries
    slice_size = max(1, n // T)

    slices = []
    for t in range(T):
        start = t * slice_size
        end = n if t == T - 1 else (t + 1) * slice_size

        chunk = candidates[start:end]
        if chunk:
            slices.append(chunk)

    return slices
