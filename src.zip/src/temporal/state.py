# ot_context/temporal/state.py

import torch
from typing import List


class ContextState:
    """
    Represents a context construction state at a given temporal step.
    """

    def __init__(
        self,
        selected: List[dict],
        cost_history: List[float],
    ):
        assert selected, "ContextState cannot be empty"
        self.selected = selected
        self.cost_history = cost_history

    @property
    def embeddings(self):
        """
        Returns stacked embeddings of selected candidates.
        """
        return torch.stack([c["emb"] for c in self.selected])

    @property
    def centroid(self):
        """
        Mean embedding of the context set.
        Used for temporal consistency cost.
        """
        return self.embeddings.mean(dim=0)

    @property
    def size(self):
        return len(self.selected)

    @property
    def final_cost(self):
        """
        Last OT cost achieved in this state.
        """
        return self.cost_history[-1]

    def summary(self):
        """
        Lightweight debug summary.
        """
        return {
            "size": self.size,
            "final_cost": self.final_cost,
        }
