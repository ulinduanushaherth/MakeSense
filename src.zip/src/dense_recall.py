# dense_recall.py
import faiss
import numpy as np
import torch
from src.encoders.encoder import Encoder

class DenseRetriever:
    def __init__(self, texts, model_name="BAAI/bge-base-en-v1.5"):
        self.encoder = Encoder(model_name=model_name)
        self.texts = texts

        # encode corpus
        embs = self.encoder.encode(texts)          # torch.Tensor
        self.embs = embs                            # keep torch copy

        embs_np = embs.numpy().astype("float32")    # FAISS copy
        dim = embs_np.shape[1]

        self.index = faiss.IndexFlatIP(dim)
        self.index.add(embs_np)

    def retrieve(self, query, top_n=200):
        q_emb = self.encoder.encode(query).numpy().astype("float32")
        _, idxs = self.index.search(q_emb, top_n)

        results = []
        for i in idxs[0]:
            results.append({
                "id": int(i),
                "text": self.texts[i],
                "emb": self.embs[i]    # torch.Tensor, not numpy
            })

        return results
