from hotpotqa_eval.query_decompose import extract_phrases
from dense_recall import DenseRetriever
from hotpotqa_eval.set_builder import build_context_set_adaptive
from temporal.state import ContextState
from temporal.temporal_cost import temporal_cost
from temporal.temporal_builder import build_temporal_context

# ------------------------------
# Toy setup
# ------------------------------
query = "Does caffeine improve long-term memory retention in adults?"

corpus = [
    "Caffeine improves alertness and attention.",
    "Long-term memory consolidation occurs during sleep.",
    "Some studies show caffeine affects memory.",
    "Caffeine intake can disrupt sleep cycles.",
    "Memory retention varies across adults."
]

# ------------------------------
# Query decomposition (THIS DEFINES q_embs)
# ------------------------------
phrases, q_embs = extract_phrases(query)

# ------------------------------
# Dense recall
# ------------------------------
retriever = DenseRetriever(corpus)
candidates = retriever.retrieve(query, top_n=5)

# ------------------------------
# Static OT (baseline sanity)
# ------------------------------
selected, cost_history = build_context_set_adaptive(
    q_embs,
    candidates,
    epsilon=0.01,
    patience=2,
    k_max=5
)

state = ContextState(selected, cost_history)
print(state.summary())
print("Centroid dim:", state.centroid.shape)
print("Temporal cost (self):", temporal_cost(state, state))

# ------------------------------
# Temporal OT (THIS USES q_embs)
# ------------------------------
states, debug = build_temporal_context(
    q_embs,
    candidates,
    num_slices=3,
)

print("\nTEMPORAL OT RESULT")
print("Num states:", len(states))
print("State sizes:", debug["state_sizes"])
print("Query costs:", debug["query_costs"])
print("Temporal costs:", debug["temporal_costs"])
