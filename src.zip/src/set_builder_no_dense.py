# ot_context/set_builder_no_dense_pruning.py

import torch
from hotpotqa_eval.ot_cost import ot_cost


def build_context_set_adaptive(
    query_embs,
    candidates,
    epsilon=0.01,
    patience=2,
    k_max=12,
    dense_prune_k=20,  # set to None to disable pruning
):
    """
    Adaptive OT-based context construction.
    Stops when semantic coverage saturates or
    when no valid candidate can be selected.

    dense_prune_k:
        - int  -> prune to top-k dense candidates
        - None -> disable dense pruning (use all remaining)
    """

    # --- basic sanity ---
    if not candidates:
        return [], []

    assert isinstance(candidates[0]["emb"], torch.Tensor)

    selected = []
    remaining = candidates.copy()

    cost_history = []
    no_gain_steps = 0
    prev_cost = None

    for step in range(k_max):

        # If nothing remains, stop
        if not remaining:
            break

        best = None
        best_cost = float("inf")

        # ------------------------------------------------
        # Dense pruning (OPTIONAL)
        # ------------------------------------------------
        if dense_prune_k is None:
            pruned = remaining
        else:
            q_centroid = query_embs.mean(dim=0, keepdim=True)

            sims = [
                torch.cosine_similarity(
                    c["emb"].unsqueeze(0), q_centroid, dim=1
                ).item()
                for c in remaining
            ]

            top_idx = sorted(
                range(len(sims)),
                key=lambda i: sims[i],
                reverse=True
            )[: min(dense_prune_k, len(remaining))]

            pruned = [remaining[i] for i in top_idx]

        # ------------------------------------------------
        # Evaluate OT cost for each candidate
        # ------------------------------------------------
        for c in pruned:
            cand_embs = torch.stack([x["emb"] for x in selected + [c]])
            cost = ot_cost(query_embs, cand_embs)

            if cost < best_cost:
                best_cost = cost
                best = c

        # ------------------------------------------------
        # If no candidate could be selected, stop cleanly
        # ------------------------------------------------
        if best is None:
            break

        # ------------------------------------------------
        # Gain computation
        # ------------------------------------------------
        if prev_cost is not None:
            gain = prev_cost - best_cost
        else:
            gain = None  # first selection

        cost_history.append(best_cost)

        # ------------------------------------------------
        # Saturation logic
        # ------------------------------------------------
        if gain is not None and gain < epsilon:
            no_gain_steps += 1
        else:
            no_gain_steps = 0

        if no_gain_steps >= patience:
            break

        # ------------------------------------------------
        # Commit selection
        # ------------------------------------------------
        selected.append(best)
        remaining.pop(remaining.index(best))
        prev_cost = best_cost

    return selected, cost_history