"""
Ablation 1: No Query Decomposition

This ablation removes semantic support extraction entirely.
The query is represented as a single embedding and passed
unchanged into the existing OT-based set construction.

Goal:
- Isolate whether gains come from OT-based set geometry
  rather than query decomposition heuristics.

This file is a DROP-IN replacement for query_decompose.extract_phrases
usage in HotpotQA evaluation.
"""

import torch
from src.encoders.encoder import Encoder

# --------------------------------------------------
# Setup
# --------------------------------------------------
encoder = Encoder()


def extract_single_query_support(query: str):
    """
    Replace extract_phrases(query).

    Returns:
        supports: [query]
        support_embs: Tensor[1, d]
    """
    emb = encoder.encode(query)  # shape: [1, d]
    return [query], emb
