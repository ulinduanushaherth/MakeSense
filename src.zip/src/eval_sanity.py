# from query_decompose import extract_phrases
# from encoders.encoder import Encoder
# from set_builder import build_context_set

# encoder = Encoder()

# query = "Does caffeine improve long-term memory retention in adults?"

# phrases, q_embs = extract_phrases(query)

# candidates = [
#     {"id": i, "text": t, "emb": encoder.encode(t)[0]}
#     for i, t in enumerate([
#         "Caffeine enhances alertness and attention.",
#         "Long-term memory consolidation occurs during sleep.",
#         "Some studies show caffeine affects memory performance.",
#         "Caffeine intake can disrupt sleep cycles.",
#         "Memory retention varies across individuals."
#     ])
# ]

# selected = build_context_set(q_embs, candidates, k=3)

# for s in selected:
#     print("-", s["text"])

# eval_sanity.py
import json

from hotpotqa_eval.query_decompose import extract_phrases
from dense_recall import DenseRetriever
from hotpotqa_eval.set_builder import build_context_set_adaptive


def load_samples(path):
    with open(path, "r") as f:
        for line in f:
            yield json.loads(line)


def run_sanity_eval(samples_path):
    samples = list(load_samples(samples_path))

    for sample in samples:
        print("\n" + "=" * 80)
        print(f"SAMPLE ID: {sample['id']}")
        print("=" * 80)

        query = sample["query"]
        corpus = sample["corpus"]

        print("\nQUERY:")
        print(query)

        # --- Query decomposition ---
        phrases, q_embs = extract_phrases(query)

        print("\nQUERY SUPPORTS:")
        for p in phrases:
            print(" -", p)

        # --- Dense recall (local corpus as retrieval universe) ---
        retriever = DenseRetriever(corpus)
        candidates = retriever.retrieve(query, top_n=min(200, len(corpus)))

        # --- Adaptive OT set construction ---
        selected, cost_history = build_context_set_adaptive(
            q_embs,
            candidates,
            epsilon=0.01,
            patience=2,
            k_max=12
        )

        print("\nSELECTED CONTEXT SET (in selection order):")
        for i, s in enumerate(selected):
            print(f"[{i+1}] {s['text']}")

        print("\nOT COST CURVE:")
        for i, c in enumerate(cost_history):
            print(f" step {i+1}: {c:.4f}")

        print("\n")


if __name__ == "__main__":
    run_sanity_eval(
        samples_path="/home/sabharishhh/MakeSense3.0/ot_context/data/samples.jsonl"
    )
