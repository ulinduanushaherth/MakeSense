import torch

from hotpotqa_eval.query_decompose import extract_phrases
from hotpotqa_eval.ot_cost import ot_cost
from src.encoders.encoder import Encoder


# --------------------------------------------------
# Setup
# --------------------------------------------------
encoder = Encoder()

query = "Does caffeine improve long-term memory retention in adults?"

candidates = [
    "Caffeine is a central nervous system stimulant that increases alertness.",
    "Long-term memory consolidation is influenced by sleep quality.",
    "Several studies have examined caffeine’s effects on memory performance.",
    "High caffeine intake can negatively affect sleep patterns.",
    "Memory retention varies across individuals and age groups.",
    "Caffeine consumption is common among adults worldwide.",
    "Some experiments show caffeine improves short-term attention but not long-term recall."
]


# --------------------------------------------------
# Query decomposition (CRITICAL difference)
# --------------------------------------------------
phrases, q_embs = extract_phrases(query)

print("QUERY SUPPORTS:")
for p in phrases:
    print(" -", p)


# --------------------------------------------------
# OT cost per candidate (singleton context)
# --------------------------------------------------
results = []

for c in candidates:
    c_emb = encoder.encode([c])[0]

    cost = ot_cost(
        q_embs,                     # query supports
        torch.stack([c_emb])        # singleton candidate set
    )

    results.append((c, cost))


# --------------------------------------------------
# Sort + display
# --------------------------------------------------
results.sort(key=lambda x: x[1])

print("\nOT COST (lower = better coverage):\n")

for c, s in results:
    print(f"{s:.4f} | {c}")