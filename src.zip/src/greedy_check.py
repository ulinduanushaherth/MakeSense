# greedy_check.py
from hotpotqa_eval.query_decompose import extract_phrases
from src.encoders.encoder import Encoder
from hotpotqa_eval.set_builder import build_context_set_adaptive

# ----------------------------
# Setup
# ----------------------------
encoder = Encoder()

query = "Does caffeine improve long-term memory retention in adults?"

corpus = [
    "Caffeine is a central nervous system stimulant that increases alertness.",
    "Long-term memory consolidation is influenced by sleep quality.",
    "Several studies have examined caffeine’s effects on memory performance.",
    "High caffeine intake can negatively affect sleep patterns.",
    "Memory retention varies across individuals and age groups.",
    "Caffeine consumption is common among adults worldwide.",
    "Some experiments show caffeine improves short-term attention but not long-term recall.",
]

# ----------------------------
# Query supports
# ----------------------------
phrases, q_embs = extract_phrases(query)

print("\nQUERY SUPPORTS:")
for p in phrases:
    print(" -", p)

# ----------------------------
# Candidate embeddings
# ----------------------------
candidates = [
    {"text": t, "emb": encoder.encode(t)[0]}
    for t in corpus
]

# ----------------------------
# Greedy OT construction
# ----------------------------
selected, cost_history = build_context_set_adaptive(
    query_embs=q_embs,
    candidates=candidates,
    k_max=6
)

print("\nGREEDY CONTEXT SET:")
for i, s in enumerate(selected):
    print(f"[{i+1}] {s['text']}")

print("\nOT COST HISTORY:")
for i, c in enumerate(cost_history):
    print(f"k={i+1}: {c:.4f}")
